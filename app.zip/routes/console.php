<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');


Schedule::command('billing:generate daily')->dailyAt('00:00');

Schedule::command('billing:generate weekly')->weeklyOn(1, '00:00'); // Monday

Schedule::command('billing:generate monthly')->monthlyOn(1, '00:00');
