<?php

namespace App\Http\Controllers\Frontend;

use App\Enums\Status;
use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\MegaCategory;
use App\Models\Product;
use App\Models\ProductGroup;
use App\Models\Slider;
use Illuminate\Http\Request;

class HomeController extends FrontendController
{
    public function index()
    {

        $categories = MegaCategory::with('subCategories.miniCategories')->get();

        $newArrivals = Product::with(['brand', 'variations.attributes.attributeValue'])
            ->where('status', Status::Active->value)
            ->withCount('reviews')
            ->withAvg('reviews', 'rating')->latest()->take(10)->get();
        // \Log::info($newArrivals);
        //for product groups
        $productGroups = ProductGroup::where('status', Status::Active->value)
            ->where('is_frontend', 1)
            ->get()
            ->map(function ($group) {
                $group->products = Product::whereIn('id', $group->product_ids ?? [])
                    ->where('status', Status::Active->value)
                    ->withCount('reviews')
                    ->withAvg('reviews', 'rating')
                    ->take(15)
                    ->get();
                return $group;
            })
            ->filter(fn($group) => $group->products->count() > 0);

        $brands = Brand::where('status', Status::Active->value)->latest()->take(10)->get();

        $popularProducts = Product::with(['brand', 'variations'])
            ->where('status', Status::Active->value)
            ->withCount('reviews')
            ->withAvg('reviews', 'rating')
            ->withSum('orderDetails as total_sales', 'quantity')
            ->orderByDesc('total_sales')
            ->take(12)
            ->get();

        $allSliders = Slider::where('status', Status::Active->value)->get();
        $mainSliders = $allSliders->where('placement', 'hero');
        $sidebarSliders = $allSliders->where('placement', 'left');
        $middleSliders = $allSliders->where('placement', 'middle')->take(2);

        return  $this->view(
            'frontend.home',
            compact(
                'categories',
                'newArrivals',
                'brands',
                'popularProducts',
                'productGroups',
                'allSliders',
                'mainSliders',
                'sidebarSliders',
                'middleSliders'
            )
        );
    }
}
