<?php

namespace App\Http\Requests\Asset;

use App\Http\Requests\UpdateBaseCompanyRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateAssetRequest extends UpdateBaseCompanyRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return array_merge($this->companyRules(), [
            'asset_category_id' => ['sometimes', 'required', 'exists:asset_categories,id'],
            'manager_id'        => ['nullable', 'exists:users,id'],
            'image'             => ['nullable', 'image', 'mimes:jpg,png,webp', 'max:2048'],
            'name'              => ['sometimes', 'required', 'string', 'max:255'],
            'asset_tag'         => ['sometimes','required'],
            'serial_number'     => ['nullable', 'string', 'max:255'],
            'model_number'      => ['nullable', 'string', 'max:255'],
            'asset_location'    => ['sometimes', 'required', 'string', 'max:255'],
            'description'       => ['nullable', 'string'],
            'status'            => ['sometimes', 'nullable','integer'],
        ]);
    }
    public function messages(): array
    {
        return array_merge($this->companyMessages(), [
            'asset_location.required'    => 'Asset location is required.',
        ]);
    }
    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'success' => false,
            'message' => 'Validation failed',
            'errors'  => $validator->errors(),
        ], 422));
    }
}
